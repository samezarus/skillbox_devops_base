Kto by si mal prečítať tento dokument?
==============================

Každý vývojár pracujúci na aplikácii, ktorá beží ako služba. Systémoví administrátori, ktorý také aplikácie nasadzujú.
