Ai nên đọc tài liệu này?
========================

Bất kì lập trình viên đang xây dựng các ứng dụng-như-một-dịch vụ. Các kỹ sư hệ
thống đảm nhiệm triển khai hoặc quản lý các ứng dụng.
